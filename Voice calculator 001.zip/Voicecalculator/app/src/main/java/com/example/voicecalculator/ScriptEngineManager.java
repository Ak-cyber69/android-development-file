package com.example.voicecalculator;

public class ScriptEngineManager {
    public ScriptEngine getEngineByName(String rhino) {
        return null;
    }
}
