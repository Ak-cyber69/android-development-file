package com.example.voicecalculator;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 1;
    private TextView resultText, spokenText;
    private Button speakButton;
    private SpeechRecognizer speechRecognizer;
    private static final String TAG = "VoiceCalculator";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        resultText = findViewById(R.id.result_text);
        spokenText = findViewById(R.id.spoken_text);
        speakButton = findViewById(R.id.speak_button);

        // Check and request microphone permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
        }

        // Initialize SpeechRecognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        setupSpeechRecognizer();

        // Button click listener
        speakButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startListening();
            }
        });
    }

    private void setupSpeechRecognizer() {
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                Log.d(TAG, "Ready for speech");
            }

            @Override
            public void onBeginningOfSpeech() {
                Log.d(TAG, "Speech started...");
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String spoken = matches.get(0).toLowerCase();
                    Log.d(TAG, "Recognized speech: " + spoken);
                    spokenText.setText("You said: " + spoken);

                    // Convert words to a math expression
                    String mathExpression = convertToExpression(spoken);
                    Log.d(TAG, "Converted Expression: " + mathExpression);

                    // Evaluate expression
                    String result = evaluateExpression(mathExpression);
                    resultText.setText("Result: " + result);
                } else {
                    Log.e(TAG, "No speech recognized");
                    Toast.makeText(MainActivity.this, "Couldn't understand, try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(int error) {
                Log.e(TAG, "Speech recognition error: " + error);
                Toast.makeText(MainActivity.this, "Error recognizing speech. Try again.", Toast.LENGTH_SHORT).show();
            }

            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { Log.d(TAG, "Speech ended."); }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startListening() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a calculation...");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);

        Log.d(TAG, "Starting speech recognition...");
        speechRecognizer.startListening(intent);
    }

    private String convertToExpression(String spoken) {
        Map<String, String> dictionary = new HashMap<>();
        dictionary.put("plus", "+");
        dictionary.put("minus", "-");
        dictionary.put("times", "*");
        dictionary.put("multiplied by", "*");
        dictionary.put("divided by", "/");
        dictionary.put("over", "/");

        for (Map.Entry<String, String> entry : dictionary.entrySet()) {
            spoken = spoken.replace(entry.getKey(), entry.getValue());
        }

        return spoken.replaceAll("[^0-9+\\-*/]", ""); // Remove unwanted characters
    }

    private String evaluateExpression(String expression) {
        try {
            return String.valueOf(new ExpressionEvaluator().evaluate(expression));
        } catch (Exception e) {
            return "Invalid Expression";
        }
    }

    // Handle permission results
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Microphone permission required for voice input", Toast.LENGTH_LONG).show();
            }
        }
    }
}
