package com.example.mysql;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {


    EditText idInput, nameInput, phoneInput;
    Button addBtn, updateBtn, deleteBtn, viewBtn;
    ListView listView;
    DBHelper db;

    ArrayList<String> contactList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);

        idInput = findViewById(R.id.idInput);
        nameInput = findViewById(R.id.nameInput);
        phoneInput = findViewById(R.id.phoneInput);
        addBtn = findViewById(R.id.addBtn);
        updateBtn = findViewById(R.id.updateBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        viewBtn = findViewById(R.id.viewBtn);
        listView = findViewById(R.id.listView);

        contactList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contactList);
        listView.setAdapter(adapter);

        addBtn.setOnClickListener(view -> {
            boolean inserted = db.insertContact(nameInput.getText().toString(), phoneInput.getText().toString());
            showMessage(inserted ? "Contact added!" : "Insert failed.");
            clearFields();
        });

        updateBtn.setOnClickListener(view -> {
            if (!idInput.getText().toString().isEmpty()) {
                boolean updated = db.updateContact(
                        Integer.parseInt(idInput.getText().toString()),
                        nameInput.getText().toString(),
                        phoneInput.getText().toString()
                );
                showMessage(updated ? "Contact updated!" : "Update failed.");
                clearFields();
            } else {
                showMessage("Enter ID to update");
            }
        });

        deleteBtn.setOnClickListener(view -> {
            if (!idInput.getText().toString().isEmpty()) {
                boolean deleted = db.deleteContact(Integer.parseInt(idInput.getText().toString()));
                showMessage(deleted ? "Contact deleted!" : "Delete failed.");
                clearFields();
            } else {
                showMessage("Enter ID to delete");
            }
        });

        viewBtn.setOnClickListener(view -> {
            contactList.clear();
            Cursor cursor = db.getAllContacts();
            if (cursor.getCount() == 0) {
                showMessage("No contacts found.");
                return;
            }
            while (cursor.moveToNext()) {
                String entry = "ID: " + cursor.getInt(0) +
                        ", Name: " + cursor.getString(1) +
                        ", Phone: " + cursor.getString(2);
                contactList.add(entry);
            }
            adapter.notifyDataSetChanged();
        });
    }

    private void showMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void clearFields() {
        idInput.setText("");
        nameInput.setText("");
        phoneInput.setText("");
    }
}
